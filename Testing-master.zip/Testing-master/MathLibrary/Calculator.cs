namespace MathLibrary;

public static class Calculator
{
    public static int Multiply(int a, int b)
    {
        return a * b;
    }

    public static bool IsEven(double a)
    {
        if (Math.Abs(a % 1) > double.Epsilon * 100)
        {
            return false;
        }
        return (long)a % 2 == 0;
    }

    public static int Divide(int a, int b)
    {
        if (b == 0)
        {
            throw new DivideByZeroException("Cannot divide by zero.");
        }
        return a / b;
    }

}