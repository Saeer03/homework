﻿namespace MathLibrary;

public class Class1
{

}
