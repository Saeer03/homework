using Xunit;
using MathLibrary;

namespace MathLibrary.Tests;

public class CalculatorTests
{
    [Fact]
    public void Multiply_TwoPositiveNumbers_ReturnsCorrectResult()
    {
        int a = 2, b = 3;
        int result = Calculator.Multiply(a, b);
        Assert.Equal(6, result);
    }

    [Fact]
    public void Multiply_NumberWithZero_ReturnsZero()
    {
        int a = 0, b = 5;
        int result = Calculator.Multiply(a, b);
        Assert.Equal(0, result);
    }

    [Fact]
    public void Multiply_NegativeAndPositiveNumber_ReturnsNegative()
    {
        int a = -2, b = 3;
        int result = Calculator.Multiply(a, b);
        Assert.Equal(-6, result);
    }

    [Fact]
    public void Multiply_TwoNegativeNumbers_ResturnsPositve()
    {
        int a = -2, b = -3;
        int result = Calculator.Multiply(a, b);
        Assert.Equal(6, result);
    }
    ///////////////////////////////////////////////////////////////////////
    [Fact]
    public void Even_ReturnsEven()
    {
        double a = 6;
        bool result = Calculator.IsEven(a);
        Assert.True(result);
    }

    [Fact]

    public void Odd_RetrunsNotEven()
    {
        double a = 5;
        bool result = Calculator.IsEven(a);
        Assert.False(result);
    }

    [Fact]
    public void Zero_ReturnsEven()
    {
        double a = 0;
        bool result = Calculator.IsEven(a);
        Assert.True(result);
    }

    [Fact]
    public void NegativeEven_ReturnsEven()
    {
        double a = -2;
        bool result = Calculator.IsEven(a);
        Assert.True(result);
    }

    [Fact]
    public void NegativeOdd_ReturnsNotEven()
    {
        double a = -3;
        bool result = Calculator.IsEven(a);
        Assert.False(result);
    }

    [Fact]
    public void Float_ReturnsNotEven()
    {
        double a = 3.14;
        bool result = Calculator.IsEven(a);
        Assert.False(result);
    }

    ///////////////////////////////////////////////////////////////


    [Fact]
    public void Divide_TwoPositiveNumbers_ReturnsCorrectResult()
    {
        int a = 6, b = 3;
        int result = Calculator.Divide(a, b);
        Assert.Equal(2, result);
    }

    [Fact]
    public void Divide_PositiveByNegative_ReturnsNegative()
    {
        int a = 10, b = -2;
        int result = Calculator.Divide(a, b);
        Assert.Equal(-5, result);
    }

    [Fact]
    public void Divide_TwoNegativeNumbers_ReturnsPositive()
    {
        int a = -12, b = -3;
        int result = Calculator.Divide(a, b);
        Assert.Equal(4, result);
    }

    [Fact]
    public void Divide_NumberByZero_ThrowsDivideByZeroException()
    {
        int a = 5, b = 0;
        Assert.Throws<DivideByZeroException>(() => Calculator.Divide(a, b));
    }

    [Fact]
    public void Divide_RoundsDown_WhenResultIsFractional()
    {
        int a = 5, b = 2;
        int result = Calculator.Divide(a, b);
        Assert.Equal(2, result);
    }
}